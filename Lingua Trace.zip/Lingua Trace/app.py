import streamlit as st
import pickle
import re

# Load the saved model and encoder
model_path = "model_v1.pkl"
encoder_path = "encoder.pkl"

with open(model_path, "rb") as model_file:
    model = pickle.load(model_file)

with open(encoder_path, "rb") as encoder_file:
    encoder = pickle.load(encoder_file)

# Function to clean and predict language
def predict_language(text):
    cleaned_text = clean_txt(text)
    prediction = model.predict([cleaned_text])
    language = encoder.inverse_transform(prediction)[0]
    return language

# Text cleaning function
def clean_txt(text):
    text = text.lower()
    text = re.sub(r'[^\w\s]', ' ', text)
    text = re.sub(r'[_0-9]', ' ', text)
    text = re.sub(r'\s\s+', ' ', text)
    return text

# Streamlit app
def main():
    st.title("Lingua Trace")
    user_input = st.text_input("Enter a text:", "")
    
    if st.button("Detect Language"):
        if user_input.strip() != "":
            language = predict_language(user_input)
            st.success(f"The language is: {language}")
        else:
            st.warning("Please enter some text.")

if __name__ == "__main__":
    main()
